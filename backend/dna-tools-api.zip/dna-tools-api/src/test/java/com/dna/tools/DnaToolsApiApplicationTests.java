package com.dna.tools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DnaToolsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
