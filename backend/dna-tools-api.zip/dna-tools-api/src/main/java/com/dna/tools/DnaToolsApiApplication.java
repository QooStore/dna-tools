package com.dna.tools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DnaToolsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DnaToolsApiApplication.class, args);
	}

}
